package it.gusto.comandiere;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new CleanterBridge(), "CleanterBridge");
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public class CleanterBridge {
    @JavascriptInterface
    public String request(String method, String path, String body) {
      HttpURLConnection conn = null;
      try {
        if (!path.equals("/health") && !path.equals("/print")) return "{\"error\":\"Percorso non consentito\"}";
        URL url = new URL("http://127.0.0.1:9100" + path);
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(15000);
        if ("POST".equals(method)) {
          conn.setDoOutput(true);
          conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
          byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
          try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
        }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder response = new StringBuilder();
        if (stream != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
          String line; while ((line = br.readLine()) != null) response.append(line);
        }
        return "{\"httpStatus\":" + code + ",\"body\":" + org.json.JSONObject.quote(response.toString()) + "}";
      } catch (Exception e) {
        return "{\"bridgeError\":" + org.json.JSONObject.quote(e.toString()) + "}";
      } finally { if (conn != null) conn.disconnect(); }
    }
  }
  @Override public void onBackPressed() { super.onBackPressed(); }
}
