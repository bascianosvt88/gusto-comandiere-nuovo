package it.gusto.comandiere;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.addJavascriptInterface(new CleanterBridge(), "GustoAndroid");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  public class CleanterBridge {
    @JavascriptInterface
    public String printReceipt(String payload) {
      HttpURLConnection conn = null;
      try {
        // Verify Cleanter is running and the printer is connected.
        JSONObject health = new JSONObject(request("GET", "http://127.0.0.1:9100/health", null));
        JSONObject printer = health.optJSONObject("printer");
        if (!"ok".equalsIgnoreCase(health.optString("status")))
          return error("Cleanter non risponde correttamente.");
        if (printer != null && !printer.optBoolean("connected", true))
          return error("Cleanter è attivo ma la PT-210 non risulta collegata.");
        JSONObject body = new JSONObject(payload);
        String response = request("POST", "http://127.0.0.1:9100/print", body.toString());
        JSONObject result = new JSONObject(response);
        String status = result.optString("status", "");
        if (!status.isEmpty() && !"printed".equals(status))
          return error(result.optString("error", "Cleanter non conferma la stampa: " + status));
        result.put("ok", true);
        return result.toString();
      } catch (Exception e) {
        return error(e.getMessage() == null ? "Errore di collegamento con Cleanter" : e.getMessage());
      } finally {
        if (conn != null) conn.disconnect();
      }
    }

    private String request(String method, String address, String body) throws Exception {
      HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
      c.setRequestMethod(method);
      c.setConnectTimeout(5000);
      c.setReadTimeout(10000);
      c.setUseCaches(false);
      if (body != null) {
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
      }
      int code = c.getResponseCode();
      InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
      StringBuilder result = new StringBuilder();
      if (stream != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
        String line; while ((line = r.readLine()) != null) result.append(line);
      }
      c.disconnect();
      if (code < 200 || code >= 300) throw new Exception("Cleanter HTTP " + code + ": " + result);
      return result.toString();
    }

    private String error(String message) {
      JSONObject out = new JSONObject();
      try { out.put("ok", false); out.put("error", message); } catch (Exception ignored) {}
      return out.toString();
    }
  }

  @Override public void onBackPressed() { super.onBackPressed(); }
}
