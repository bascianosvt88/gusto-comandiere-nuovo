# Gusto Comandiere Android

App Android locale che carica il file HTML incluso in `app/src/main/assets/index.html`.

La compilazione GitHub Actions produce l'APK debug come artifact. L'HTML è incluso nell'APK; funzioni che comunicano con servizi remoti richiedono comunque una connessione Internet.
