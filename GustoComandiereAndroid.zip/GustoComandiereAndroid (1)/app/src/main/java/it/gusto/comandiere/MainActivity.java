package it.gusto.comandiere;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView web;
  private final ExecutorService printExecutor = Executors.newSingleThreadExecutor();
  private final Handler mainHandler = new Handler(Looper.getMainLooper());
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.addJavascriptInterface(new CleanterBridge(), "GustoCleanter");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  private class CleanterBridge {
    @JavascriptInterface public void requestAsync(String method, String body, String callbackName) {
      printExecutor.execute(() -> {
        String result = request(method, body);
        String js = "window.__gustoPrintCallbacks && window.__gustoPrintCallbacks(" + JSONObject.quote(callbackName) + "," + JSONObject.quote(result) + ");";
        mainHandler.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
      });
    }
    @JavascriptInterface public String request(String method, String body) {
      HttpURLConnection c = null;
      try {
        c = (HttpURLConnection)new URL("http://127.0.0.1:9100" + ("GET".equals(method) ? "/health" : "/print")).openConnection();
        c.setRequestMethod("GET".equals(method) ? "GET" : "POST");
        c.setConnectTimeout(5000); c.setReadTimeout(10000);
        if (!"GET".equals(method)) {
          c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
          byte[] data = (body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8);
          try (OutputStream os = c.getOutputStream()) { os.write(data); }
        }
        int status = c.getResponseCode();
        InputStream in = status >= 200 && status < 400 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line=r.readLine())!=null) sb.append(line); }
        JSONObject result = new JSONObject(); result.put("httpStatus", status); result.put("body", sb.toString()); return result.toString();
      } catch (Exception e) { try { JSONObject result = new JSONObject(); result.put("error", e.toString()); return result.toString(); } catch(Exception ignored) { return "{\"error\":\"request failed\"}"; } }
      finally { if (c != null) c.disconnect(); }
    }
  }
  @Override public void onBackPressed() { super.onBackPressed(); }
}
