package it.gusto.comandiere;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowUniversalAccessFromFileURLs(true);
    web.addJavascriptInterface(new CleanterBridge(), "CleanterNative");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public class CleanterBridge {
    @JavascriptInterface public String printReceipt(String payload) {
      HttpURLConnection c = null;
      try {
        URL url = new URL("http://127.0.0.1:9100/print");
        c = (HttpURLConnection)url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(5000); c.setReadTimeout(15000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);
        try(OutputStream os=c.getOutputStream()){ os.write(bytes); }
        int code=c.getResponseCode();
        InputStream is=(code>=200 && code<400)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        if(is!=null){ byte[] buf=new byte[4096]; int r; while((r=is.read(buf))!=-1)out.write(buf,0,r); is.close(); }
        JSONObject result; try { result=new JSONObject(out.toString("UTF-8")); } catch(Exception e){ result=new JSONObject(); result.put("detail",out.toString("UTF-8")); }
        result.put("httpStatus",code); return result.toString();
      } catch(Exception e) { try { JSONObject err=new JSONObject(); err.put("error",e.toString()); return err.toString(); } catch(Exception ignored){ return "{\"error\":\"Cleanter connection failed\"}"; } }
      finally { if(c!=null)c.disconnect(); }
    }
  }
  @Override public void onBackPressed() { super.onBackPressed(); }
}
